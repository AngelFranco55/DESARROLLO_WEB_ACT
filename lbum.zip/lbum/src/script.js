// Array (Arreglo) para las imágenes
const imagenes = [
  "https://www.brandonsanderson.com/cdn/shop/files/2.png?v=1722015641&width=640",
 "https://www.17thshard.com/uploads/monthly_2021_02/TEM_2.jpg.b744cea3cc4f65e5ceaf424448fde30c.jpg",
  "https://www.brandonsanderson.com/cdn/shop/files/Untitled_design_18.png?v=1722041987&width=640",
  "https://www.brandonsanderson.com/cdn/shop/files/Untitled_design_19.png?v=1722041986&width=640",
 "https://www.brandonsanderson.com/cdn/shop/files/Untitled_design_1.png?v=1722017816&width=640",
 "https://imgv2-2-f.scribdassets.com/img/document/835939450/original/e6d8dae38b/1?v=1", 
  "https://www.brandonsanderson.com/cdn/shop/files/Untitled_design_21.png?v=1722042891&width=640",
  "https://www.brandonsanderson.com/cdn/shop/files/Untitled_design_22.png?v=1722043010&width=640",
  "https://m.media-amazon.com/images/I/71ISjS3nFsL._UF894,1000_QL80_.jpg", // Imagen Amazon en 9
  "https://www.brandonsanderson.com/cdn/shop/files/Untitled_design_23.png?v=1722043009&width=640"
];

// Selección de elementos
const boton = document.getElementById("btn-cambiar");
const imageCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

let indice = 0;

boton.addEventListener("click", () => {
  indice++;

  if (indice >= imagenes.length) {
    indice = 0;
  }

  // Cambiar la imagen
  imageCard.src = imagenes[indice];
  textoCard.textContent = `Imagen ${indice + 1} de ${imagenes.length}`;
});
